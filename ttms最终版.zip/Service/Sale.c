#include "Sale.h"
#include "../Persistence/Sale_Persist.h"
#include "../Persistence/Ticket_Persist.h"
#include <stdio.h>
#include <stdlib.h>
#include "../Common/List.h"

int Sale_Srv_Add(const sale_t *data) {
    return Sale_Perst_Insert(data);
}
int Ticket_Srv_Modify(const ticket_t *data) {
    return Ticket_Perst_Update(data);
}
int Ticket_Srv_FetchBySchID(int ID, ticket_t *list) {
    return Ticket_Srv_SelBySchID(ID, list);
}

ticket_node_t * Ticket_Srv_FetchBySeatID(ticket_list_t list, int seat_id) {

	ticket_node_t *p;
	List_ForEach(list, p){
		if(p->data.seat_id==seat_id)
			return p;
	}
	return NULL;
}

int Ticket_Srv_FetchAll(ticket_list_t list,int schID)
{
    return Ticket_Perst_SelectAll(list,schID);
}

int Sale_Srv_FetchByticket(int ticket_id,sale_t *sale)
{
    return Sale_Perst_SelByTicketID(ticket_id,sale);

}

