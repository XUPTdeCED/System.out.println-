#include "../Common/List.h"
#include "../Persistence/EntityKey_Persist.h"

#include "Ticket.h"
#include "Seat.h"
#include "Sale.h"

#include "../Persistence/Ticket_Persist.h"
#include "../Persistence/Play_Persist.h"

#include <stdio.h>

//��ʶ����TTMS_SCU_Schedule_Srv_FetchByID
//����: ����ID��ȡ�ݳ��ƻ�
int Schedule_Srv_FetchByID(int  id, schedule_t  *buf){
    return Schedule_Perst_SelectByID(id, buf);
}

//��ʶ����TTMS_SCU_Ticket_Srv_Gen
//����: ͨ���־û��㺯�������������ļ�Ticket.dat�е���Ϣ
int Ticket_Srv_GenBatch(int schedule_id , int studio_id) {
    ticket_t data;
	ticket_list_t list=NULL;
	seat_list_t seat_head;
	ticket_node_t *newNode;
	schedule_t sch;
	play_t  play;

	long id_seed;

	int count=0;
	int recCount = 0;

	List_Init(seat_head, seat_node_t);
	count = Seat_Srv_FetchValidByRoomID(seat_head,studio_id);
	if(count==0){
		printf("not seat information,can not create tickets.\n");
		return 0;
	}

	//�����ݳ��ƻ�����Ŀ
	Schedule_Perst_SelectByID(schedule_id, &sch);
	Play_Perst_SelectByID(sch.play_id, &play);

	List_Init(list,ticket_node_t);

    seat_node_t *pos;
    id_seed=EntKey_Perst_GetNewKeys("Ticket",count);
    pos=seat_head->next;
	while(pos!=seat_head){
			data.seat_id=pos->data.id;
			data.schedule_id=schedule_id;
			data.status= TICKET_AVL;	//��ʾ����
			data.id=id_seed++;
			data.price=play.price;		//Ĭ��ͳһƱ��
			newNode = (ticket_node_t*) malloc(sizeof(ticket_node_t));
			if (!newNode) {
				printf("Warning, Memory OverFlow!!!\n Cannot Load more Data into memmory!!!\n");
				break;
			}
			recCount++;
			newNode->data = data;
			List_AddTail(list, newNode);
		pos=pos->next;
	}
	Ticket_Perst_Insert(list);
	return recCount;
}



//��ʶ����TTMS_SCU_Ticket_Srv_Del
//����:   �����ݳ��ƻ���IDɾ���ݳ�Ʊ
int Ticket_Srv_DeleteBatch(int schedule_id){
    return Ticket_Perst_Rem(schedule_id);
}

int Ticket_Srv_StatRevSchID(int schedule_id,int *soldCount)
{
    int value = 0;//���Ʊ��
    ticket_list_t list;
    ticket_node_t *p;
    sale_t sale;
    List_Init(list,ticket_node_t);
    *soldCount = 0;//��Ч��Ʊ������ 	//

   // *soldCount = Ticket_Srv_FetchBySchID(schedule_id,list);
    //+
    //Ticket_Srv_FetchBySchID(schedule_id,list);
    Ticket_Perst_SelectAll(list, schedule_id);
    List_ForEach(list,p) {
    //  Sale_Srv_FetchByticket(p->data.id,&sale);
    //   sale.type = 1;
        //if(sale.type == 1 && p->data.status == 1)//ȷ��Ϊ��Ʊ״̬����ȷ��Ϊ����
        //printf("%d\n",p->data.id);
        if(p->data.status==1)
        {

            *soldCount++;
            value +=  p->data.price;
        }
    }

    List_Destroy(list , ticket_node_t);
    return value;
}
