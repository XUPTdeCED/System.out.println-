#include "Account.h"
#include "../Persistence/Account_Persist.h"
#include "../Persistence/EntityKey_Persist.h"
#include "../Common/List.h"
#include <string.h>
#include <stdio.h>
#include <io.h>
static const char ACCOUNT_DATA_FILE[] = "Account.dat";
static const char SEAT_KEY_NAME[] = "Account";
void Account_Srv_InitSys()
{
    if(!access(ACCOUNT_DATA_FILE,0))
        return;
    account_t data_admin;
    data_admin.id = EntKey_Perst_GetNewKeys(SEAT_KEY_NAME,1);
    strcpy(data_admin.password , "admin");
    strcpy(data_admin.username , "admin");
    data_admin.type = USR_ADMIN;
    Account_Srv_Add(&(data_admin));
}

int Account_Srv_Verify(char usrName[], char pwd[])
{
    account_t usr;
    Account_Perst_SelByName(usrName,&usr);
    if(strcmp(usr.password,pwd) != 0)
        return 0;
    gl_CurUser = usr;
    return 1;
}

int Account_Srv_Add(const account_t *data)
{
    return Account_Perst_Insert(data);
}

int Account_Srv_Modify(const account_t *data)
{
    return Account_Perst_Update(data);
}

int Account_Srv_DeleteByID(int usrID)
{
    return Account_Perst_RemByID(usrID);
}

int Account_Srv_FetchAll(account_list_t list)
{
    int userCount = 0;
    userCount = Account_Perst_SelectAll(list);
    return userCount;
}

account_node_t * Account_Srv_FindByUsrName(account_list_t list, char usrName[])
{
    account_node_t *pos;
    List_ForEach(list,pos)
        if(strcmp(pos->data.username,usrName) == 0 )
            return pos;
    return NULL;
}
