#ifndef SALESANALYSIS_UI_H_
#define SALESANALYSIS_UI_H_

#include "../Common/List.h"
#include "../Service/Account.h"
#include "../Service/Ticket.h"
#include "../Service/Play.h"
#include "../Service/Schedule.h"
#include "../Service/Sale.h"

void SalesAnalysis_UI_MgtEntry ();

#endif
