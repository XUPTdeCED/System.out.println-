#include "Sale_UI.h"
#include "Seat_UI.h"

#include "../Persistence/Play_Persist.h"
#include "../Persistence/Sale_Persist.h"
#include "../Persistence/EntityKey_Persist.h"

#include "../Service/play.h"
#include "../Service/schedule.h"
#include "../Service/seat.h"
#include "../Service/account.h"
#include "../Service/Ticket.h"
#include "../Service/Sale.h"
#include "../Service/Studio.h"

#include "../Common/List.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>

static const int PLAY_PAGE_SIZE = 5;
static const int SCHEDULE_PAGE_SIZE = 5;

//���ݾ�ĿID��ʾ�ݳ��ƻ�
void Sale_UI_MgtEntry()
{
    int id,i;
    char choice;

    play_list_t head;
    play_node_t *pos;
    Pagination_t paging;

    List_Init( head , play_node_t);
    Play_Srv_FetchAll(head);

    paging.offset = 0;
	paging.pageSize = PLAY_PAGE_SIZE;

	paging.totalRecords = Play_Srv_FetchAll(head);
	Paging_Locate_FirstPage(head, paging);
	do{
        printf("\n=================================================================================================\n");
        printf("**************************************** �� ʾ �� Ŀ ********************************************\n\n\n");
        printf("%4s %10s %10s %10s %10s %14s %8s\n\n\n", "��Ŀ���", "��Ŀ����",
                        "��Ʒ����","��Ŀʱ��","��ӳ����","��������","Ʊ��");
        printf("-------------------------------------------------------------------------------------------------\n");
        //
        Paging_ViewPage_ForEach(head, paging, play_node_t, pos, i){
            printf("%4d %10s %10s %10d ", pos->data.id,
						pos->data.name, pos->data.area, pos->data.duration);
            printf("%10.4d/%.2d/%.2d  %8.4d/%.2d/%.2d  %4d\n\n\n",pos->data.start_date.year,pos->data.start_date.month,pos->data.start_date.day,pos->data.offline_date.year,pos->data.offline_date.month,pos->data.offline_date.day,pos->data.price);
        }
        printf("~~~~~~~~~~~~~~~~~~~~~~ ��ҳ��:%2d ~~~~~~~~~~~~~~~~~~~~~~~~~~ ��ǰҳ %2d/%2d ~~~~~~~~~~~~~~~~~~~~~\n\n",
					paging.totalRecords, Pageing_CurPage(paging),
					Pageing_TotalPages(paging));
        printf("*************************************************************************************************\n");
        printf("              P   ��һҳ   |   N   ��һҳ   |   C   ��ʾ�ݳ��ƻ�   |   R   �����ϲ�");
        printf("\n=================================================================================================\n");
        printf("����������ѡ��:");
        fflush(stdin);
        scanf("%c", &choice);
        getchar();

        switch (choice) {
		case 'c':
		case 'C':
		    printf("�������ĿID:");
		    scanf("%d",&id);
		    system("cls");
            while(!Play_Srv_FetchByID( id , &head->data))
            {
                printf("�����ڸþ�Ŀ,�����������ĿID:\n");
                scanf("%d",&id);
            }

            Sale_UI_ShowScheduler(id);
            paging.totalRecords = Play_Srv_FetchAll(head);
            List_Paging(head, paging, play_node_t);
		    break;
        case 'p':
		case 'P':
			if (!Pageing_IsFirstPage(paging)) {
				Paging_Locate_OffsetPage(head, paging, -1, play_node_t);
			}
			break;
		case 'n':
		case 'N':
			if (!Pageing_IsLastPage(paging)) {
				Paging_Locate_OffsetPage(head, paging, 1, play_node_t);
			}
			break;
        }
    }while (choice != 'r' && choice != 'R');
    system("cls");
    //�ͷ������ռ�
	List_Destroy(head, play_node_t);
}


//����playID��ʾ�ݳ��ƻ�
void Sale_UI_ShowScheduler(int playID)
{
    int i, id;
	char choice;

    schedule_t *temp;
	schedule_list_t head;
	schedule_node_t *pos;

	play_t  buf;

	Pagination_t paging;
	temp = (schedule_t*)malloc(sizeof(schedule_t));

    Play_Perst_SelectByID(playID, &buf);

	List_Init(head, schedule_node_t);
	paging.offset = 0;
	paging.pageSize = SCHEDULE_PAGE_SIZE;

	//��������
	paging.totalRecords = Schedule_Srv_FetchAll(head);
	Paging_Locate_FirstPage(head, paging);

    //�ж������ݳ��ƻ��еľ�ĿID�У��Ƿ��д���������ID
    //���������ʾ�ݳ��ƻ�
    //�������û����þ�Ŀ��ص��ݳ��ƻ�


	do {
		printf(
				"\n=================================================================================================\n");
		printf(
				"************************************* �� �� Ŀ �� �� �� �� �� ***********************************\n\n\n");
		printf( "%5s  %10s  %10s  %10s %8s\n\n\n", "�ݳ��ƻ����", "��ӳ��Ŀ����", "�ݳ������",
				"��ӳ����", "��ӳʱ��" );
		printf( "-------------------------------------------------------------------------------------------------\n");
		//��ʾ����
		Paging_ViewPage_ForEach(head, paging, schedule_node_t, pos, i){
		    if(pos->data.play_id == playID){

                printf("%5d  %10s  %10d ", pos->data.id, buf.name ,pos->data.studio_id);
                printf("%12.4d/%.2d/%.2d  ",pos->data.date.year,pos->data.date.month,pos->data.date.day);
                printf("%8.2d:%.2d:%.2d  \n",pos->data.time.hour,pos->data.time.minute,pos->data.time.second);
		    }
		}
		printf("~~~~~~~~~~~~~~~~~~~~~~ ��ҳ��:%2d ~~~~~~~~~~~~~~~~~~~~~~~~~~~ ��ǰҳ %2d/%2d ~~~~~~~~~~~~~~~~~~~~\n\n",
				paging.totalRecords, Pageing_CurPage(paging),
				Pageing_TotalPages(paging));
		printf("*************************************************************************************************\n");
		printf("        P   ��һҳ    |    N    ��һҳ    |    S    ��ʾ����Ʊ��Ϣ    |    R    �����ϲ�");
		printf("\n=================================================================================================\n");
		printf("����������ѡ��:");
		fflush(stdin);
		scanf("%c", &choice);
		getchar();
		switch (choice) {

        case 's':
        case 'S':
            printf("����������Ҫ���ݳ��ƻ����:\n");
            scanf("%d",&id);
            system("cls");
            while(!Schedule_Srv_FetchByID(id , temp))
            {
                printf("�����ڸ��ݳ��ƻ�,����������:\n");
                scanf("%d",&id);
            }
            Sale_UI_ShowTicket(id);
            break;
		case 'p':
		case 'P':
			if (!Pageing_IsFirstPage(paging)) {
				Paging_Locate_OffsetPage(head, paging, -1, schedule_node_t);
			}
			break;
		case 'n':
		case 'N':
			if (!Pageing_IsLastPage(paging)) {
				Paging_Locate_OffsetPage(head, paging, 1, schedule_node_t);
			}
			break;
		}
	} while (choice != 'r' && choice != 'R');
	system("cls");
	free(temp);
	//�ͷ������ռ�
	List_Destroy(head, schedule_node_t);
}


//���ݼƻ�ID����ʾ�ݳ�Ʊ
void Sale_UI_ShowTicket(int schID)
{
    char choice;
    int i;

    schedule_t *schedule;
    seat_list_t seat;
    ticket_list_t head;
    ticket_node_t *pos;
    Pagination_t paging;

    schedule = (schedule_t*)malloc(sizeof(schedule_t));
    List_Init(seat,seat_node_t);
    List_Init(head,ticket_node_t);
    paging.offset = 0;
	paging.pageSize = 8;

    paging.totalRecords = Ticket_Srv_FetchAll(head,schID);
    Paging_Locate_FirstPage(head, paging);
    do{
        printf("\n=================================================================================================\n");
        printf("***************************************** �� �� Ʊ �� �� ****************************************\n\n\n");
        printf("%10s %10s %10s %10s %14s\n\n\n", "�ݳ�ƱID", "�ݳ��ƻ�ID",
                        "��λID","Ʊ��","��ǰƱ��״̬");
        printf("-------------------------------------------------------------------------------------------------\n");
        //
        Paging_ViewPage_ForEach(head, paging, ticket_node_t, pos, i){
            printf("%10d %10d %10d %10d %14d\n", pos->data.id,pos->data.schedule_id,pos->data.seat_id,pos->data.price, pos->data.status);
        }
        printf("~~~~~~~~~~~~~~~~~~~~~~~ ��ҳ��:%2d ~~~~~~~~~~~~~~~~~~~~~~~ ��ǰҳ %2d/%2d ~~~~~~~~~~~~~~~~~~~~~~~\n\n",
                paging.totalRecords, Pageing_CurPage(paging),
                Pageing_TotalPages(paging));
        printf(" [0] ���� | [1] ���� | [9] Ԥ��\n");
        printf("*************************************************************************************************\n");
        printf("            P     ��һҳ    |     N     ��һҳ    |     B    ��Ʊ    |    R    �����ϲ�");
        printf("\n=================================================================================================\n");

        printf("����������ѡ��:");
        fflush(stdin);

        scanf("%c", &choice);
        getchar();
        switch(choice){
            case 'b':
			case 'B':
			    system("cls");
			    Schedule_Srv_FetchByID(schID,schedule);
                Seat_Srv_FetchByRoomID(seat,schedule->studio_id);
				Sale_UI_SellTicket(head,seat,schedule->studio_id);
				break;
            case 'p':
			case 'P':
				if (!Pageing_IsFirstPage(paging)) 	//��һҳ
				{
					Paging_Locate_OffsetPage(head, paging, -1, ticket_node_t);
				}
				break;
			case 'n':
			case 'N':
				if (!Pageing_IsLastPage(paging)) 	//��һҳ
				{
					Paging_Locate_OffsetPage(head, paging, 1, ticket_node_t);
				}
				break;
        }
    }while (choice != 'r' && choice != 'R');
    system("cls");
		//�ͷ�����
    List_Destroy(head, ticket_node_t);
    List_Destroy(seat,seat_node_t);

}

//��Ʊ
int Sale_UI_SellTicket(ticket_list_t tickList, seat_list_t seatList, int studioID)
{
    int x,y;
    studio_t studioRec;
    seat_node_t *seatRec;
    ticket_node_t *ticketRec,*ticketTemp;

    Studio_Srv_FetchByID(studioID, &studioRec);


    printf("\n==================================================================================================\n");
    printf("************************************  �� �� �� �� λ �� Ϣ  **************************************\n");
    printf("--------------------------------------------------------------------------------------------------\n\n\n");
    seat_node_t *seatdata;
    int i,j;
    printf("               ");
    for(j = 1; j <= studioRec.colsCount; j++ )
        printf("%2d ",j);
    printf("\n");
    for (i = 1; i <= studioRec.rowsCount; i++)
    {
        j=1;
        printf("  \t%2d��: ", i);
        List_ForEach(seatList,seatdata)
        {
            if (seatdata->data.row == i)
            {
                while (seatdata->data.column != j && j <= studioRec.colsCount) {
                    printf("%3c", ' ');
                    j++;
                }
                ticketTemp = Ticket_Srv_FetchBySeatID(tickList,seatdata->data.id);
                if(ticketTemp->data.status == 0)
                    printf("%3c", Seat_UI_Status2Char(seatdata->data.status));
                else
                    printf("%3c", Seat_UI_Status2Char(9));
                j++;
            }
        }
            printf("\n");
    }
    printf("--------------------------------------------------------------------------------------------------\n\n");
    printf("                 [#] �ɹ�      |      [X] ���ۻ���       |       [|] ����\n");
    printf(
           "\n==================================================================================================\n");
    do
    {
        printf("���������Ĺ���Ʊ���к�: ");
        scanf("%d", &x);
        printf("���������Ĺ���Ʊ���к�: ");
        scanf("%d", &y);
    }while(studioRec.rowsCount<x||studioRec.colsCount<y);
    seatRec = Seat_Srv_FindByRowCol(seatList,x,y);
    ticketRec = Ticket_Srv_FetchBySeatID(tickList,seatRec->data.id);
    if(ticketRec == NULL)
    {
        printf("��Ʊʧ��!\n");
        return 0;
    }
    if(ticketRec->data.status == 1 || ticketRec->data.status == 9)
    {
        printf("��Ʊ����,�����ظ�����\n");
        return 0;
    }
    ticketRec->data.status = 1;
    if(Ticket_Srv_Modify(&ticketRec->data))
    {
        printf("��Ʊ�ɹ���\n");

        sale_t sale;

        sale.id=EntKey_Perst_GetNewKeys("Ticket_Sale", 1);

        user_date_t temp1;
        user_time_t temp2;
        temp1 = DateNow();
        temp2 = TimeNow();

        sale.date.day = temp1.day;
        sale.date.month = temp1.month;
        sale.date.year = temp1.day;

        sale.time.hour = temp2.hour;
        sale.time.minute = temp2.minute;
        sale.time.second = temp2.second;

        sale.ticket_id = ticketRec->data.id;
        sale.user_id = gl_CurUser.id;
        sale.value = ticketRec->data.price;
        sale.type = 1;
        Sale_Srv_Add(&sale);
        return 1;
    }
    else
    {
        printf("��Ʊʧ��!\n");
        return 0;
    }

}


//��Ʊ
void Sale_UI_ReturnTicket()
{
    int id;
    ticket_t temp;

    printf("������Ʊ��ID��\n");
    scanf("%d",&id);
    if(!Ticket_Srv_FetchBySchID( id, &temp))
    {
        printf("û���ҵ���Ӧ��Ʊ!\n�밴 [Enter] ����!\n");
        getchar();
        getchar();
        return ;
    }
    else
    {
        if(temp.status==0)
        {
            printf("��Ʊ��û���۳����޷���Ʊ��\n");
        }
        if(temp.status==1)
        {
            temp.status = 0;
            Ticket_Srv_Modify(&temp);
            sale_t refound;

            refound.id=EntKey_Perst_GetNewKeys("Ticket_Refound", 1);

            user_date_t temp1;
            user_time_t temp2;
            temp1 = DateNow();
            temp2 = TimeNow();

            refound.date.day = temp1.day;
            refound.date.month = temp1.month;
            refound.date.year = temp1.day;

            refound.time.hour = temp2.hour;
            refound.time.minute = temp2.minute;
            refound.time.second = temp2.second;

            refound.ticket_id = temp.id;
            refound.user_id = gl_CurUser.id;
            refound.value = -temp.price;
            refound.type = -1;

            Sale_Srv_Add(&refound);
            printf("��Ʊ�ɹ���\n");
        }
    }
}
