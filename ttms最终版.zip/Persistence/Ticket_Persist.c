#include "Ticket_Persist.h"
#include <stdio.h>
#include "../Service/Ticket.h"
#include "EntityKey_Persist.h"
#include "Play_Persist.h"

#include <assert.h>

static const char TICKET_DATA_FILE[] = "Ticket.dat"; //�ݳ����ļ�������
//static const char TICKET_DATA_TEMP_FILE[] = "TicketTmp.dat"; //�ݳ�����ʱ�ļ�������
//static const char TICKET_KEY_NAME[] = "Ticket"; //�ݳ���������



//��ʶ����TTMS_SCU_Schedule_Perst_SelByID
//����:  ����ID�����ݳ��ƻ�
int Schedule_Perst_SelectByID(int  id, schedule_t  *buf) {
    int found = 0;
    FILE *fp;
    schedule_t data;
    fp = fopen("Schedule.dat", "rb");
    if (fp == NULL) {
        printf("Schedule.dat can not be open!");
        return found;
    } else {
        while (!feof(fp)) {
            fread(&data, sizeof(schedule_t), 1, fp);
            if (data.id == id) {
                * buf = data;
                found = 1;
                break;
            }
        }
    }
    fclose(fp);
    return found;
}

//��ʶ��: TTMS_SCU_Ticket_Perst_Insert
//����:  ��Ʊ���ļ�Ticket.dat����������list�����ϵ�����Ʊ����Ϣ
int Ticket_Perst_Insert(ticket_list_t  list) {
    /*schedule_t * sch;
    play_t *buf;
    ticket_t  *data;

    fp = fopen("Ticket.dat", "ab+");
    if (fp == NULL) {
        printf("Ticket.dat can not open");
        return 0;
    } else {
        ticket_list_t pos, t;
        t = list->next;
        while(t) {
        Schedule_Perst_SelectByID(t->data.schedule_id, sch);
        Play_Perst_SelectByID(sch->play_id, buf);
        buf->id = EntKey_Perst_GetNewKeys(buf->name, 1);
        t = t->next;
        }
        pos = list->next;
        while(pos){  // ������λ��;
            count++;
            data = pos;
            rtn = fwrite(&data, sizeof(ticket_t), 1, fp);
            pos = pos->next;
        }
    }
    fclose(fp);
    return rtn;*/
	ticket_node_t *pos;
	int rtn = 0;
	FILE *fp = fopen(TICKET_DATA_FILE, "ab");
	if (NULL == fp) {
		printf("Cannot open file %s!\n", TICKET_DATA_FILE);
		return 0;
	}
    pos=list->next;
	while(pos!=list){
		rtn = fwrite(&(pos->data), sizeof(ticket_t), 1, fp);
		pos=pos->next;
	}
	fclose(fp);
	return rtn;

}


//��ʶ����TTMS_SCU_Ticket_Perst_Rem
//����:  ��Ʊ���ļ�Ticket.dat������ɾ���ݳ��ƻ�ID��Ϊschedule_id������Ʊ����Ϣ
int Ticket_Perst_Rem(int schedule_id) {
    int found = -1;
    FILE * fp, *ftp;
    ticket_t buf;
    if (rename("Ticket.dat","TicketTmp.dat") < 0) {
        printf("����ʧ�ܣ�");
        return found;
    }
    else {
        fp = fopen("TicketTmp.dat", "rb");
        ftp = fopen("Ticket.dat", "wb+");
        if (fp == NULL && ftp == NULL) {
            printf("�ļ���ʧ��");
            return found;
        }
        else {
            found = 0;
            while (!feof(fp)){
                fread(&buf, sizeof(ticket_t), 1, fp);
                if (buf.id == schedule_id) {
                    found++;
                }
                else {
                    fwrite(&buf, sizeof(ticket_t), 1, ftp);
                }
            }
        }
    }
    fclose (fp);
    fclose (ftp);
    return found;
}
