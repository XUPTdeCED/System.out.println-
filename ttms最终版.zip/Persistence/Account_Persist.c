#include "Account_Persist.h"
#include "EntityKey_Persist.h"
#include "../Common/List.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
static const char ACCOUNT_DATA_FILE[] = "Account.dat";
static const char ACCOUNT_DATA_TEMP_FILE[] = "AccountTmp.dat";
int Account_Perst_CheckAccFile()
{
    return access(ACCOUNT_DATA_FILE,0);
}

int Account_Perst_SelByName(char usrName[], account_t *buf)
{
    FILE *fp = fopen(ACCOUNT_DATA_FILE, "rb");
	if (NULL == fp) {
		printf("�޷����ļ� %s!\n", ACCOUNT_DATA_FILE);
		return 0;
	}

	account_t data;
	int found = 0;

	while (!feof(fp)) {
		if (fread(&data, sizeof(account_t), 1, fp)) {
			if (strcmp(usrName,data.username)==0) {
				*buf = data;
				found = 1;
				break;
			}
		}
	}
	fclose(fp);
    return found;
}

int Account_Perst_Insert(const account_t *data)
{
    assert(NULL!=data);
	FILE *fp=fopen(ACCOUNT_DATA_FILE,"ab");
	int rtn=0;
	if (NULL==fp)
	{
		printf("�޷����ļ� %s!\n", ACCOUNT_DATA_FILE);
		return 0;
	}
	rtn=fwrite(data,sizeof(account_t),1,fp);
	fclose(fp);
	return rtn;
}

int Account_Perst_Update(const account_t *data)
{
    int found = 0;
	FILE *fp;
	account_t buf;
	fp = fopen(ACCOUNT_DATA_FILE, "rb+");
	if (fp == NULL) {
			printf("�޷����ļ� %s!\n", ACCOUNT_DATA_FILE);
			return 0;
	}
    while(!feof(fp)) {
        if(fread(&buf, sizeof(buf), 1, fp)){
            if (buf.id == data->id) {
                fseek(fp, -((int)sizeof(account_t)), SEEK_CUR);
                fwrite(data, sizeof(account_t), 1, fp);
                found = 1;
                break;
            }
        }
    }

	fclose(fp);
	return found;
}

int Account_Perst_RemByID(int id)
{
    int found = 0;
	FILE * fp, *ftp;
	account_t  buf;
	if(rename(ACCOUNT_DATA_FILE, ACCOUNT_DATA_TEMP_FILE)<0){
		printf("Cannot rename file %s!\n", ACCOUNT_DATA_FILE);
		return 0;
	}
	//��ԭʼ�ļ���������Ȼ���ȡ��������д�뵽�����ļ��У�����Ҫɾ����ʵ����˵���
	//��ԭʼ�����ļ�������

	fp = fopen(ACCOUNT_DATA_TEMP_FILE, "rb");
	if (NULL == fp ){
		printf("Cannot open file %s!\n",ACCOUNT_DATA_TEMP_FILE);
		return 0;
	}

	ftp = fopen(ACCOUNT_DATA_FILE, "wb");
	if ( NULL == ftp ) {
		printf("Cannot open file %s!\n", ACCOUNT_DATA_FILE);
		return 0;
	}
	else {
		while(!feof(fp)) {
			fread(&buf, sizeof(buf), 1, fp);
			if (buf.id == id) {
				found = 1;
			}
			else {
				fwrite(&buf, sizeof(account_t), 1, ftp);
			}
		}
		fclose(fp);
		fclose(ftp);
		remove(ACCOUNT_DATA_TEMP_FILE);
		return found;
	}
}

int Account_Perst_SelectByID(int id, account_t *buf)
{
    assert(NULL!=buf);

	FILE *fp = fopen(ACCOUNT_DATA_FILE, "rb");
	if (NULL == fp) {
		return 0;
	}

	account_t data;
	int found = 0;

	while (!feof(fp)) {
		if (fread(&data, sizeof(account_t), 1, fp)) {
			if (id == data.id) {
				*buf = data;
				found = 1;
				break;
			};

		}
	}
	fclose(fp);
	return found;

}

int Account_Perst_SelectAll(account_list_t list)
{
    account_node_t *newNode;
	account_t data;
    int recCount = 0;
    assert(NULL != list);

    FILE *fp = fopen("Account.dat", "rb+");
	if (NULL == fp) { //�ļ�������
		return 0;
	}

	while (!feof(fp)) {
		if (fread(&data, sizeof(account_t), 1, fp)) {
			newNode = (account_node_t*) malloc(sizeof(account_node_t));
			if (!newNode) {
				printf("Warning, Memory OverFlow!!!\n Cannot Load more Data into memory!!!\n");
				break;
			}
			newNode->data = data;
			List_AddTail(list, newNode);
			recCount++;
		}
	}
	fclose(fp);
	return recCount;
}
